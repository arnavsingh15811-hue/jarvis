JARVIS for Android - build steps
1. Install Android Studio (free) from developer.android.com/studio
2. File > Open > select this "jarvis" folder. Let Gradle sync finish.
3. Plug in your phone (Developer options + USB debugging on) and press Run.
   Or: Build > Build APK(s), then copy app-debug.apk to the phone and install it.
4. Get an API key at console.anthropic.com, paste it in the app, tap Save key.
5. Tap "Tap and talk", or "Start always-on Jarvis" and say: "Jarvis, what are my tasks today?"
Try: "Jarvis, add task buy milk" / "set an alarm for 6:30" / "timer 10 minutes" / "open YouTube"
Note: API usage is billed to your Anthropic account. Keep your key private.
