package com.jarvis.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class Assistant(private val ctx: Context) : TextToSpeech.OnInitListener {
    private val prefs = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private val tools = Tools(ctx)
    private var client: ClaudeClient? = null
    private var lastKey = ""
    private var ready = false
    private val tts = TextToSpeech(ctx, this)

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) tts.language = Locale.getDefault()
    }

    /** Runs on a background thread; calls finished(reply) from that thread. */
    fun handle(text: String, finished: (String) -> Unit) {
        Thread {
            val key = prefs.getString("key", "")?.trim() ?: ""
            val reply = if (key.isEmpty()) {
                "Please add your API key in the app first."
            } else try {
                if (client == null || key != lastKey) { client = ClaudeClient(key, tools); lastKey = key }
                client!!.ask(text)
            } catch (e: Exception) {
                "Sorry, something went wrong. ${e.message}"
            }
            finished(reply)
        }.start()
    }

    fun speak(text: String, finished: () -> Unit = {}) {
        if (!ready) { finished(); return }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { finished() }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { finished() }
        })
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    fun shutdown() { tts.stop(); tts.shutdown() }
}
