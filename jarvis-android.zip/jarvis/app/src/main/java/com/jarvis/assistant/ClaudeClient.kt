package com.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ClaudeClient(private val apiKey: String, private val tools: Tools) {
    companion object { const val MODEL = "claude-sonnet-5-5" }

    private var history = JSONArray()

    fun ask(text: String): String {
        if (history.length() > 30) history = JSONArray()
        history.put(JSONObject().put("role", "user").put("content", text))
        repeat(6) {
            val content = call().getJSONArray("content")
            history.put(JSONObject().put("role", "assistant").put("content", content))
            val results = JSONArray()
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                when (b.getString("type")) {
                    "text" -> sb.append(b.getString("text"))
                    "tool_use" -> results.put(
                        JSONObject().put("type", "tool_result")
                            .put("tool_use_id", b.getString("id"))
                            .put("content", tools.run(b.getString("name"), b.getJSONObject("input")))
                    )
                }
            }
            if (results.length() == 0) return sb.toString().trim()
            history.put(JSONObject().put("role", "user").put("content", results))
        }
        return "Sorry, that took too many steps."
    }

    private fun call(): JSONObject {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy HH:mm z", Locale.getDefault()).format(Date())
        val system = "You are Jarvis, a concise voice assistant on the user's Android phone. " +
            "Your replies are spoken aloud: keep them short and natural, no markdown or lists. " +
            "Use tools to act on the phone. Be proactive: after answering about tasks or schedule, " +
            "briefly suggest one useful next step. Current time: $now."
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 1024)
            .put("system", system)
            .put("tools", tools.definitions())
            .put("messages", history)
        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("x-api-key", apiKey)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.setRequestProperty("content-type", "application/json")
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw Exception("API error $code")
        return JSONObject(text)
    }
}
