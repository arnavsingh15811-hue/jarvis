package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Always-on listener: say "Jarvis, <request>" (or "Jarvis" then the request). */
class JarvisService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private lateinit var assistant: Assistant
    private var awaiting = false
    private var running = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        assistant = Assistant(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis is listening")
            .setContentText("Say \"Jarvis\" followed by your request")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        listen(0)
    }

    private fun listen(delay: Long) {
        if (!running) return
        main.postDelayed({ if (running) startRec() }, delay)
    }

    private fun startRec() {
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase() ?: ""
                onHeard(t)
            }
            override fun onError(error: Int) { listen(800) }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        )
        rec = r
    }

    private fun onHeard(t: String) {
        val idx = t.indexOf("jarvis")
        val cmd: String? = when {
            awaiting -> t
            idx >= 0 -> t.substring(idx + 6).trim()
            else -> null
        }
        if (cmd == null) { listen(300); return }
        if (cmd.isBlank()) {
            awaiting = true
            assistant.speak("Yes?") { main.post { listen(0) } }
            return
        }
        awaiting = false
        assistant.handle(cmd) { reply ->
            main.post { assistant.speak(reply) { main.post { listen(300) } } }
        }
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        rec?.destroy()
        assistant.shutdown()
        super.onDestroy()
    }
}
