package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var assistant: Assistant
    private lateinit var log: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        assistant = Assistant(this)
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        requestPermissions(
            arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CALENDAR, Manifest.permission.POST_NOTIFICATIONS), 1
        )

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        val key = EditText(this).apply {
            hint = "Anthropic API key (sk-ant-...)"
            setText(prefs.getString("key", ""))
            setSingleLine()
        }
        val save = Button(this).apply {
            text = "Save key"
            setOnClickListener { prefs.edit().putString("key", key.text.toString().trim()).apply(); say("Key saved.") }
        }
        val talk = Button(this).apply { text = "Tap and talk"; setOnClickListener { listenOnce() } }
        val start = Button(this).apply {
            text = "Start always-on Jarvis"
            setOnClickListener { startForegroundService(Intent(this@MainActivity, JarvisService::class.java)) }
        }
        val stop = Button(this).apply {
            text = "Stop always-on Jarvis"
            setOnClickListener { stopService(Intent(this@MainActivity, JarvisService::class.java)) }
        }
        log = TextView(this).apply { textSize = 16f; text = "Jarvis ready.\n" }
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            addView(log)
        }
        listOf(key, save, talk, start, stop, scroll).forEach { root.addView(it) }
        setContentView(root)
    }

    private fun say(s: String) { log.append("$s\n") }

    private fun listenOnce() {
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                runOnUiThread { say("You: $t") }
                assistant.handle(t) { reply ->
                    runOnUiThread { say("Jarvis: $reply"); assistant.speak(reply) }
                }
                r.destroy()
            }
            override fun onError(error: Int) { runOnUiThread { say("Didn't catch that (error $error).") }; r.destroy() }
            override fun onReadyForSpeech(p: Bundle?) { runOnUiThread { say("Listening...") } }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        )
    }

    override fun onDestroy() { assistant.shutdown(); super.onDestroy() }
}
