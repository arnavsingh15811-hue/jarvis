package com.jarvis.assistant

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.provider.CalendarContract
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class Tools(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    private fun tool(name: String, desc: String, props: JSONObject = JSONObject(), req: List<String> = emptyList()) =
        JSONObject().put("name", name).put("description", desc).put(
            "input_schema",
            JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req))
        )

    private fun str(d: String) = JSONObject().put("type", "string").put("description", d)
    private fun num(d: String) = JSONObject().put("type", "integer").put("description", d)

    fun definitions(): JSONArray = JSONArray()
        .put(tool("get_today_events", "List today's calendar events."))
        .put(tool("list_tasks", "List the user's to-do tasks (numbered)."))
        .put(tool("add_task", "Add a to-do task.", JSONObject().put("task", str("Task text")), listOf("task")))
        .put(tool("complete_task", "Mark a task done by its number from list_tasks.", JSONObject().put("number", num("1-based task number")), listOf("number")))
        .put(tool("set_alarm", "Set an alarm (24h clock).",
            JSONObject().put("hour", num("0-23")).put("minute", num("0-59")).put("label", str("Alarm label")), listOf("hour", "minute")))
        .put(tool("set_timer", "Start a countdown timer.",
            JSONObject().put("seconds", num("Duration in seconds")).put("label", str("Timer label")), listOf("seconds")))
        .put(tool("open_app", "Open an installed app by name.", JSONObject().put("name", str("App name")), listOf("name")))
        .put(tool("add_calendar_event", "Open a pre-filled new calendar event for the user to save.",
            JSONObject().put("title", str("Event title"))
                .put("start", str("Local start time, format yyyy-MM-dd'T'HH:mm"))
                .put("duration_minutes", num("Length in minutes, default 60")), listOf("title", "start")))

    fun run(name: String, i: JSONObject): String {
        return try {
            when (name) {
                "get_today_events" -> events()
                "list_tasks" -> listTasks()
                "add_task" -> { val t = tasks(); t.put(i.getString("task")); saveTasks(t); "Added." }
                "complete_task" -> {
                    val t = tasks(); val n = i.getInt("number") - 1
                    if (n < 0 || n >= t.length()) "No such task." else { val done = t.getString(n); t.remove(n); saveTasks(t); "Done: $done" }
                }
                "set_alarm" -> {
                    launch(Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, i.getInt("hour"))
                        .putExtra(AlarmClock.EXTRA_MINUTES, i.getInt("minute"))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, i.optString("label", "Jarvis"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)); "Alarm set."
                }
                "set_timer" -> {
                    launch(Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, i.getInt("seconds"))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, i.optString("label", "Jarvis"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)); "Timer started."
                }
                "open_app" -> openApp(i.getString("name"))
                "add_calendar_event" -> {
                    val start = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(i.getString("start"))!!.time
                    val end = start + i.optInt("duration_minutes", 60) * 60000L
                    launch(Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
                        .putExtra(CalendarContract.Events.TITLE, i.getString("title"))
                        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
                        .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)); "Event screen opened."
                }
                else -> "Unknown tool."
            }
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }

    private fun launch(intent: Intent) { ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    private fun tasks() = JSONArray(prefs.getString("tasks", "[]"))
    private fun saveTasks(t: JSONArray) { prefs.edit().putString("tasks", t.toString()).apply() }
    private fun listTasks(): String {
        val t = tasks()
        if (t.length() == 0) return "No tasks."
        return (0 until t.length()).joinToString("\n") { "${it + 1}. ${t.getString(it)}" }
    }

    private fun events(): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val start = cal.timeInMillis
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon()
            .also { ContentUris.appendId(it, start); ContentUris.appendId(it, start + 86400000L) }.build()
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        val sb = StringBuilder()
        ctx.contentResolver.query(
            uri, arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN),
            null, null, "${CalendarContract.Instances.BEGIN} ASC"
        )?.use { c ->
            while (c.moveToNext()) sb.append(fmt.format(Date(c.getLong(1)))).append(" ").append(c.getString(0)).append("\n")
        }
        return if (sb.isEmpty()) "No events today." else sb.toString()
    }

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val q = name.lowercase()
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) } ?: return "App not found."
        val intent = pm.getLaunchIntentForPackage(m.activityInfo.packageName) ?: return "Cannot open it."
        launch(intent)
        return "Opened."
    }
}
